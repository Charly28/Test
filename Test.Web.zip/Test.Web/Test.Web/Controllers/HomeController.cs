﻿using Newtonsoft.Json;
using Test.Core.Services.Cars;

namespace Test.Web.Controllers
{
    using System.Diagnostics;
    using Microsoft.AspNetCore.Mvc;
    using Core.Models;

    public class HomeController : Controller
    {
        private readonly ICarService _carService;

        public HomeController(ICarService carService)
        {
            _carService = carService;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Add()
        {
            return View();
        }

        public IActionResult Edit(int? id)
        {
            var car = _carService.GetCar(id.Value);
            ViewBag.SelectedCar = JsonConvert.SerializeObject(car);
            return View();
        }

        public IActionResult Delete(int? id)
        {
            var car = _carService.GetCar(id.Value);
            ViewBag.SelectedCar = JsonConvert.SerializeObject(car);
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        public JsonResult ListCars()
        {
            return Json(_carService.GetCars());
        }

        [HttpPost]
        public CarViewModel AddCar([FromBody] CarViewModel model)
        {
            return _carService.Add(model);
        }


        [HttpPost]
        public CarViewModel UpdateCar([FromBody] CarViewModel model)
        {
            return _carService.Edit(model);
        }

        [HttpPost]
        public ActionResult DeleteCar([FromBody] CarViewModel model)
        {
            _carService.Delete(model.Id);

            dynamic data = new
            {
                message = "Car deleted!",
                redirectUrl = Url.Action("Index", "Home")
            };

            return new JsonResult(data);
        }

    }
}
