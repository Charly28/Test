﻿namespace Test.Core.Services.Cars
{
    using System.Collections.Generic;
    using Models;

    public interface ICarService
    {
        List<CarViewModel> GetCars();
        CarViewModel GetCar(int carId);
        CarViewModel Add(CarViewModel carViewModel);
        CarViewModel Edit(CarViewModel carViewModel);
        void Delete(int carId);
    }
}
