﻿namespace Test.Core.Services.Cars
{
    using System.Collections.Generic;
    using Newtonsoft.Json;
    using Common;
    using Models;
    using System.Linq;

    public class CarService : ICarService
    {
        public CarService()
        {

        }

        public List<CarViewModel> GetCars()
        {
            JsonHelper readWrite = new JsonHelper();
            var carDtos = JsonConvert.DeserializeObject<List<CarViewModel>>(readWrite.Read("Cars.json", "data"));

            return carDtos;
        }

        public CarViewModel GetCar(int carId)
        {
            JsonHelper readWrite = new JsonHelper();
            var cars = JsonConvert.DeserializeObject<List<CarViewModel>>(readWrite.Read("Cars.json", "data"));
            CarViewModel car = cars.FirstOrDefault(x => x.Id == carId);

            return car;
        }

        public CarViewModel Add(CarViewModel carViewModel)
        {
            JsonHelper readWrite = new JsonHelper();
            var cars = JsonConvert.DeserializeObject<List<CarViewModel>>(readWrite.Read("Cars.json", "data"));

            var Id = cars.OrderByDescending(x => x.Id).FirstOrDefault()?.Id;

            carViewModel.Id = (int)(Id != null ? Id + 1 : 0);

            cars.Add(carViewModel);

            string jSonString = JsonConvert.SerializeObject(cars);
            readWrite.Write("Cars.json", "data", jSonString);

            return carViewModel;
        }

        public CarViewModel Edit(CarViewModel carViewModel)
        {
            JsonHelper readWrite = new JsonHelper();
            var cars = JsonConvert.DeserializeObject<List<CarViewModel>>(readWrite.Read("Cars.json", "data"));

            int index = cars.FindIndex(x => x.Id == carViewModel.Id);
            cars[index] = carViewModel;

            string jSonString = JsonConvert.SerializeObject(cars);
            readWrite.Write("Cars.json", "data", jSonString);

            return carViewModel;
        }

        public void Delete(int carId)
        {
            JsonHelper readWrite = new JsonHelper();
            var cars = JsonConvert.DeserializeObject<List<CarViewModel>>(readWrite.Read("Cars.json", "data"));
            int index = cars.FindIndex(x => x.Id == carId);

            cars.RemoveAt(index);

            string jSonString = JsonConvert.SerializeObject(cars);
            readWrite.Write("Cars.json", "data", jSonString);
        }
    }
}
